How to interact with SNARL:
- Everything is in the command line
    - Follow the prompts in the command line
    - Make sure that the inputs are properly formatted as the prompts ask
- Level visuals are in ascii data format
    - Look at labels to figure out what data represents what part of the level.
    