ZOMBIE
---
* Zombies randomly move around the room until a player comes within a 5 tile 
* If another valid move is not avaliable i.e. adversary, door, or wall tile, then the zombie can skip their turn otherwise they must move
* If a player comes withing 5 tiles of a zombie they will make a move towards the player's direction

GHOST
---
* Ghosts try to find players by moving to walls and warping around the level
* If another valid move is not avaliable i.e. adversary, door, or wall tile, then the ghost can skip their turn otherwise they must 
* If a player scomes within 9 tiles of a ghost they will make a move towards the player's direction