#!/usr/bin/env python

WHITE = (255,255,255)
BLACK = (0, 0, 0)
GREY = (125, 125, 125)
YELLOW = (255, 225, 125)
BLUE = (0, 0, 255)
RED = (255, 0, 0)
WIDTH = 700
HEIGTH = 500
SIZE = 25